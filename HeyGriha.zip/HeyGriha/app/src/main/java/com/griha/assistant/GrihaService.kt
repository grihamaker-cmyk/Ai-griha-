package com.griha.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import java.util.Locale

class GrihaService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    private var model: Model? = null
    private var speech: SpeechService? = null
    private var tts: TextToSpeech? = null
    private var awaitingUntil = 0L
    private lateinit var commands: CommandHandler

    // "हे गृह" / "हे ग्रह" / "ग्रीहा" jaise roop (Vosk Hindi kaise sunta hai uske hisaab se badal sakte ho)
    private val wakeRegex = Regex("(हे|हेय|हाय)?\\s*(गृह|ग्रह|ग्रिह|ग्रीह|गरिह|गिरह)\\p{M}*")

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel("griha", "Hey Griha", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = NotificationCompat.Builder(this, "griha")
            .setContentTitle("Hey Griha sun raha hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build()
        ServiceCompat.startForeground(
            this, 1, n,
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        )
        commands = CommandHandler(this)
        tts = TextToSpeech(this, this)
        StorageService.unpack(this, "model-hi", "model",
            { m -> model = m; startListening() },
            { e -> Log.e("Griha", "Model load fail: ${e.message}"); stopSelf() })
    }

    private fun startListening() {
        val m = model ?: return
        speech = SpeechService(Recognizer(m, 16000.0f), 16000.0f).also { it.startListening(this) }
    }

    override fun onInit(status: Int) {
        tts?.language = Locale("hi", "IN")
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { speech?.setPause(false) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { speech?.setPause(false) }
        })
    }

    private fun speak(msg: String) {
        speech?.setPause(true) // apni hi awaaz na sune
        tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "griha")
    }

    private fun dispatch(cmd: String) = speak(commands.handle(cmd))

    override fun onResult(hypothesis: String?) {
        val text = try { JSONObject(hypothesis ?: return).optString("text") } catch (e: Exception) { return }
        if (text.isBlank()) return
        Log.d("Griha", "suna: $text")
        val now = System.currentTimeMillis()
        if (wakeRegex.containsMatchIn(text)) {
            val rest = wakeRegex.replace(text, " ").trim()
            if (rest.isBlank()) { awaitingUntil = now + 8000; speak("जी, बोलिए") } else dispatch(rest)
        } else if (now < awaitingUntil) {
            awaitingUntil = 0; dispatch(text)
        }
    }

    override fun onPartialResult(hypothesis: String?) {}
    override fun onFinalResult(hypothesis: String?) { onResult(hypothesis) }
    override fun onError(exception: Exception?) { Log.e("Griha", "mic error: ${exception?.message}") }
    override fun onTimeout() {}

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        speech?.stop(); speech?.shutdown()
        tts?.shutdown()
        super.onDestroy()
    }
}
