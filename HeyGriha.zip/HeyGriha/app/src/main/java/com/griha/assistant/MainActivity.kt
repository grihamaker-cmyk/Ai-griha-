package com.griha.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val info = TextView(this).apply {
            text = "Hey Griha\n\nStart dabao. Permissions maangi jayengi:\n" +
                "1) Mic + Notification\n2) Display over other apps (ON)\n3) Battery: Unrestricted\n\n" +
                "Phir bolo: \"हे गृह\" ... \"अगला गाना\""
            textSize = 18f
        }
        val start = Button(this).apply { text = "Start Hey Griha"; setOnClickListener { setup() } }
        val stop = Button(this).apply {
            text = "Stop"
            setOnClickListener { stopService(Intent(this@MainActivity, GrihaService::class.java)) }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
            addView(info); addView(start); addView(stop)
        })
    }

    private fun setup() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        if (perms.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            requestPermissions(perms.toTypedArray(), 1); return
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Hey Griha ko ON karke wapas aao, phir Start dabao", Toast.LENGTH_LONG).show()
            return
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        startForegroundService(Intent(this, GrihaService::class.java))
        Toast.makeText(this, "Hey Griha chalu hai", Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) setup()
        else Toast.makeText(this, "Mic permission zaruri hai", Toast.LENGTH_LONG).show()
    }
}
