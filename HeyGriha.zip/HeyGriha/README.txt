HEY GRIHA - v1 (offline voice assistant, Android)

SETUP
1) Vosk Hindi model download karo: vosk-model-small-hi-0.22
   (alphacephei.com/vosk/models) aur unzip karo.
2) Us folder ke andar ki saari files app/src/main/assets/model-hi/ me daalo
   (model-hi ke andar seedha am/, conf/, graph/ ... dikhne chahiye).
3) model-hi folder me "uuid" naam ki ek text file banao, usme kuch bhi likho (jaise: hi-1).
4) Android Studio me HeyGriha folder kholo -> Gradle sync -> phone par Run.
5) App kholo -> Start dabao -> sab permissions do.

BOLNE KE TAREeKE
  "हे गृह" ... (ruko, "जी, बोलिए") ... "अगला गाना"
  "हे गृह अगला गाना" (ek saath bhi chalega)
  "हे गृह यूट्यूब पर अरिजीत सिंह चलाओ"
  "हे गृह व्हाट्सएप खोलो" / "आवाज बढ़ाओ" / "गाना रोको"

NOTE
- Wake word Vosk se pakda jaata hai. Agar "हे गृह" na pakde to
  GrihaService.kt me wakeRegex me wo spelling jod do jo Logcat (tag: Griha) me dikhe.
- Xiaomi/Oppo/Vivo: Autostart + Battery "No restrictions" zaruri.
- Android 14+ me phone restart ke baad app ek baar khol kar Start dabana padega.
