package com.griha.assistant

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import java.text.Normalizer

class CommandHandler(private val ctx: Context) {
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val fillers = setOf(
        "पर", "में", "से", "का", "की", "के", "चलाओ", "चला", "बजाओ", "बजा", "खोलो", "खोल", "दिखाओ",
        "सर्च", "करो", "कर", "दो", "वीडियो", "गाना", "गाने", "प्ले", "प्लीज", "मेरे", "लिए", "एक", "ओपन", "चालू", "शुरू"
    )

    private val apps = listOf(
        listOf("व्हाट्सएप", "वाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "whatsapp") to "com.whatsapp",
        listOf("यूट्यूब", "youtube") to "com.google.android.youtube",
        listOf("स्पॉटिफाई", "स्पोटिफाई", "spotify") to "com.spotify.music",
        listOf("क्रोम", "गूगल", "chrome") to "com.android.chrome",
        listOf("मैप", "नक्शा") to "com.google.android.apps.maps",
        listOf("जीमेल", "gmail") to "com.google.android.gm",
        listOf("इंस्टाग्राम", "instagram") to "com.instagram.android",
        listOf("फोनपे", "phonepe") to "com.phonepe.app",
        listOf("गूगलपे", "gpay") to "com.google.android.apps.nbu.paisa.user",
    )

    private fun norm(s: String) =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace("\u093C", "").trim()

    private fun has(t: String, vararg w: String) = w.any { t.contains(it) }

    private fun media(code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun launch(i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); true
    } catch (e: Exception) { false }

    private fun query(t: String) = t.replace(Regex("यू\\s*ट्यूब"), " ")
        .split(Regex("\\s+")).filter { it.isNotBlank() && it !in fillers }.joinToString(" ")

    private fun youtubeSearch(q: String): Boolean {
        val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
        return launch(Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.youtube")) ||
            launch(Intent(Intent.ACTION_VIEW, uri))
    }

    fun handle(raw: String): String {
        val t = norm(raw)
        val c = t.replace(" ", "")

        // Volume
        if (has(c, "आवाज", "वॉल्यूम", "वोल्यूम", "volume")) {
            return when {
                has(c, "बढा", "तेज", "ज्यादा", "ऊपर") -> { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); "ठीक है" }
                has(c, "कम", "घटा", "धीमा", "नीचे") -> { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); "ठीक है" }
                else -> "आवाज बढ़ानी है या कम करनी है"
            }
        }

        // YouTube
        if (has(c, "यूट्यूब", "youtube")) {
            val q = query(t)
            if (q.isBlank()) { launch(ctx.packageManager.getLaunchIntentForPackage("com.google.android.youtube") ?: return "यूट्यूब नहीं मिला"); return "यूट्यूब खोल रही हूँ" }
            return if (youtubeSearch(q)) "यूट्यूब पर $q" else "यूट्यूब नहीं खुल पाया"
        }

        // Open app
        if (has(c, "खोल", "ओपन")) {
            if (has(c, "कैमरा")) { launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); return "कैमरा खुल गया" }
            if (has(c, "सेटिंग")) { launch(Intent(Settings.ACTION_SETTINGS)); return "सेटिंग खुल गई" }
            if (has(c, "फोन", "डायलर")) { launch(Intent(Intent.ACTION_DIAL)); return "डायलर खुल गया" }
            for ((names, pkg) in apps) if (has(c, *names.toTypedArray())) {
                val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return "वो ऐप फोन में नहीं है"
                launch(i); return "खोल दिया"
            }
            // English label se fallback
            val pm = ctx.packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            for (ri in pm.queryIntentActivities(main, 0)) {
                val label = ri.loadLabel(pm).toString().lowercase()
                if (label.length > 2 && t.contains(label)) {
                    launch(pm.getLaunchIntentForPackage(ri.activityInfo.packageName) ?: continue); return "खोल दिया"
                }
            }
            return "कौन सा ऐप खोलूँ"
        }

        // Music controls
        if (has(c, "अगला", "अगले", "नेक्स्ट", "बदल", "स्किप")) { media(KeyEvent.KEYCODE_MEDIA_NEXT); return "अगला गाना" }
        if (has(c, "पिछला", "पिछले", "प्रीवियस", "पीछे")) { media(KeyEvent.KEYCODE_MEDIA_PREVIOUS); return "पिछला गाना" }
        if (has(c, "रोक", "रुक", "पॉज", "स्टॉप", "बंद")) { media(KeyEvent.KEYCODE_MEDIA_PAUSE); return "ठीक है" }
        if (has(c, "चलाओ", "बजाओ", "चला", "बजा", "प्ले", "चालू", "शुरू")) {
            val q = query(t)
            if (q.isBlank()) { media(KeyEvent.KEYCODE_MEDIA_PLAY); return "ठीक है" }
            val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                .putExtra(SearchManager.QUERY, q)
            return if (launch(i) || youtubeSearch(q)) "$q चला रही हूँ" else "गाना नहीं चल पाया"
        }
        return "समझ नहीं आया"
    }
}
